Illustrates the use of the file operation API for performing actions such as copy/move/delete/rename on file system objects.

Build and run the exe to see it in action.