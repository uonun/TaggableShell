// FileTimeShlExt.h : Declaration of the CFileTimeShlExt

#ifndef __FILETIMESHLEXT_H_
#define __FILETIMESHLEXT_H_

/////////////////////////////////////////////////////////////////////////////
// CFileTimeShlExt

class ATL_NO_VTABLE CFileTimeShlExt : 
    public CComObjectRootEx<CComSingleThreadModel>,
    public CComCoClass<CFileTimeShlExt, &CLSID_FileTimeShlExt>,
    public IShellExtInit,
    public IShellPropSheetExt
{
public:
    CFileTimeShlExt() { }

    BEGIN_COM_MAP(CFileTimeShlExt)
        COM_INTERFACE_ENTRY(IShellExtInit)
        COM_INTERFACE_ENTRY(IShellPropSheetExt)
    END_COM_MAP()

    DECLARE_REGISTRY_RESOURCEID(IDR_FILETIMESHLEXT)

public:
    // IShellExtInit
    STDMETHODIMP Initialize(LPCITEMIDLIST, LPDATAOBJECT, HKEY);

    // IShellPropSheetExt
    STDMETHODIMP AddPages(LPFNADDPROPSHEETPAGE, LPARAM);
    STDMETHODIMP ReplacePage(UINT, LPFNADDPROPSHEETPAGE, LPARAM) { return E_NOTIMPL; }

protected:
    string_list m_lsFiles;
};

#endif //__FILETIMESHLEXT_H_
