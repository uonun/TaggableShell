//------------------------------------------------------------------------------
// RegProtocol.rc2
//------------------------------------------------------------------------------
// File provided for Microsoft Shared Source.
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF 
// ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO 
// THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A 
// PARTICULAR PURPOSE.
//------------------------------------------------------------------------------
//
// Protocol Handler implementation for the registry indexer
//
//------------------------------------------------------------------------------

#include "pch.h"
#include "resids.h"
#include <searchapi.h>
#include "RegPH.h"
#include "RegAccessor.h"

class ATL_NO_VTABLE CRegProtocol :
    public CComObjectRootEx<CComMultiThreadModel>,
    public CComCoClass<CRegProtocol, &__uuidof(RegProtocol)>,
    public ISearchProtocol2
{
public:
    CRegProtocol()
    {
    }

    DECLARE_NO_REGISTRY()

    BEGIN_COM_MAP(CRegProtocol)
        COM_INTERFACE_ENTRY2(ISearchProtocol, ISearchProtocol2)
        COM_INTERFACE_ENTRY(ISearchProtocol2)
    END_COM_MAP()

    DECLARE_PROTECT_FINAL_CONSTRUCT()   

    HRESULT FinalConstruct()
    {
        return S_OK;
    }

    void FinalRelease()
    {
    }

    // ISearchProtocol
    STDMETHOD(Init)(TIMEOUT_INFO *pTimeoutInfo, IProtocolHandlerSite *pProtocolHandlerSite, PROXY_INFO *pProxyInfo);
    STDMETHOD(CreateAccessor)(PCWSTR pcwszURL, AUTHENTICATION_INFO *pAuthenticationInfo, INCREMENTAL_ACCESS_INFO *pIncrementalAccessInfo, ITEM_INFO *pItemInfo, __deref_out IUrlAccessor **ppAccessor);
    STDMETHOD(CloseAccessor)(IUrlAccessor *pAccessor);
    STDMETHOD(ShutDown)();

    // ISearchProtocol2
    STDMETHOD(CreateAccessorEx)(PCWSTR pcwszURL, AUTHENTICATION_INFO *pAuthenticationInfo, INCREMENTAL_ACCESS_INFO *pIncrementalAccessInfo, ITEM_INFO *pItemInfo, const BLOB *pUserData, __deref_out IUrlAccessor **ppAccessor);

private:
    // private methods here
};

OBJECT_ENTRY_AUTO(__uuidof(RegProtocol), CRegProtocol)

// ISearchProtocol
STDMETHODIMP CRegProtocol::Init(TIMEOUT_INFO *pTimeoutInfo, IProtocolHandlerSite *pProtocolHandlerSite, PROXY_INFO *pProxyInfo)
{
    return S_OK;
}

STDMETHODIMP CRegProtocol::CreateAccessor(PCWSTR pcwszURL, AUTHENTICATION_INFO *pAuthenticationInfo, INCREMENTAL_ACCESS_INFO *pIncrementalAccessInfo, ITEM_INFO *pItemInfo, __deref_out IUrlAccessor **ppAccessor)
{
    return CreateAccessorEx(pcwszURL, pAuthenticationInfo, pIncrementalAccessInfo, pItemInfo, NULL, ppAccessor);
}

STDMETHODIMP CRegProtocol::CloseAccessor(IUrlAccessor *pAccessor)
{
    return S_OK;
}

STDMETHODIMP CRegProtocol::ShutDown()
{
    return S_OK;
}

// ISearchProtocol2
STDMETHODIMP CRegProtocol::CreateAccessorEx(PCWSTR pszURL, AUTHENTICATION_INFO *pAuthenticationInfo, INCREMENTAL_ACCESS_INFO *pIncrementalAccessInfo, ITEM_INFO *pItemInfo, const BLOB *pUserData, __deref_out IUrlAccessor **ppAccessor)
{
    return CRegAccessor::s_CreateInstance(pszURL, IID_PPV_ARGS(ppAccessor));
}
