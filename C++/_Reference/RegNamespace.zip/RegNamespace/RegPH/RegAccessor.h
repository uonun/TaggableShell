//------------------------------------------------------------------------------
// RegAccessor.h
//------------------------------------------------------------------------------
// File provided for Microsoft Shared Source.
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF 
// ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO 
// THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A 
// PARTICULAR PURPOSE.
//------------------------------------------------------------------------------
//
// URL Accessor implementation for the registry indexer
//
//------------------------------------------------------------------------------

#include "RegPH.h"

class ATL_NO_VTABLE CRegAccessor :
    public CComObjectRootEx<CComMultiThreadModel>,
    public CComCoClass<CRegAccessor, &__uuidof(RegAccessor)>,
    public IUrlAccessor2
{
public:
    static HRESULT s_CreateInstance(PCWSTR pszPath, REFIID riid, __deref_out void **ppv);

    CRegAccessor()
    {
    }

    DECLARE_NO_REGISTRY()

    BEGIN_COM_MAP(CRegAccessor)
        COM_INTERFACE_ENTRY2(IUrlAccessor, IUrlAccessor2)
        COM_INTERFACE_ENTRY(IUrlAccessor2)
    END_COM_MAP()

    DECLARE_PROTECT_FINAL_CONSTRUCT()   

    HRESULT FinalConstruct()
    {
        return S_OK;
    }

    void FinalRelease()
    {
    }

    // IUrlAccessor
    IFACEMETHODIMP AddRequestParameter(PROPSPEC *pSpec, PROPVARIANT *pVar);
    IFACEMETHODIMP GetDocFormat(__out_ecount_part(dwSize, *pdwLength) WCHAR wszDocFormat[], DWORD dwSize, __out DWORD *pdwLength);
    IFACEMETHODIMP GetCLSID(__out CLSID *pClsid);
    IFACEMETHODIMP GetHost(__out_ecount_part(dwSize, *pdwLength) WCHAR wszHost[], DWORD dwSize, __out DWORD *pdwLength);
    IFACEMETHODIMP IsDirectory();
    IFACEMETHODIMP GetSize(__out ULONGLONG *pllSize);
    IFACEMETHODIMP GetLastModified(__out FILETIME *pftLastModified);
    IFACEMETHODIMP GetFileName(__out_ecount_part(dwSize, *pdwLength) WCHAR wszFileName[], DWORD dwSize, __out DWORD *pdwLength);
    IFACEMETHODIMP GetSecurityDescriptor(__out_ecount_full(dwSize) BYTE *pSD, DWORD dwSize, __out DWORD *pdwLength);
    IFACEMETHODIMP GetRedirectedURL(__out_ecount_part(dwSize, *pdwLength) WCHAR wszRedirectedURL[], DWORD dwSize, __out DWORD *pdwLength);
    IFACEMETHODIMP GetSecurityProvider(__out CLSID *pSPClsid);
    IFACEMETHODIMP BindToStream(__deref_out IStream **ppStream);
    IFACEMETHODIMP BindToFilter(__deref_out IFilter **ppFilter);

    // IUrlAccessor2
    IFACEMETHODIMP GetDisplayUrl(__out_ecount_part(dwSize, *pdwLength) WCHAR wszDocUrl[], DWORD dwSize, __out DWORD *pdwLength);
    IFACEMETHODIMP IsDocument();
    IFACEMETHODIMP GetCodePage(__out_ecount_part(dwSize, *pdwLength) WCHAR wszCodePage[], DWORD dwSize, __out DWORD *pdwLength);

private:
    HRESULT _Initialize(PCWSTR pszUrl);

private:
    CComPtr<IShellItem2> _spItem;    
};
