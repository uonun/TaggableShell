//------------------------------------------------------------------------------
// RegFilter.h
//------------------------------------------------------------------------------
// File provided for Microsoft Shared Source.
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF 
// ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO 
// THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A 
// PARTICULAR PURPOSE.
//------------------------------------------------------------------------------
//
// Registry IFilter implementation for the registry indexer
//
//------------------------------------------------------------------------------

#include "RegPH.h"
#include "propkey.h"

//------------------------------------------------------------------------------
// filter handler for a key or value in the registry
//------------------------------------------------------------------------------
class CRegFilter :
    public CComObjectRootEx<CComMultiThreadModel>,
    public CComCoClass<CRegFilter, &CLSID_RegFilter>,
    public IFilter
{
public:
    CRegFilter() : _fs(FS_PROPERTIES), _ulChunkId(0), _lcid(GetUserDefaultLCID()), _cProps(0)
    {        
    };    

    ~CRegFilter();

    DECLARE_NO_REGISTRY()

    BEGIN_COM_MAP(CRegFilter)        
        COM_INTERFACE_ENTRY(IFilter)
    END_COM_MAP()

    DECLARE_PROTECT_FINAL_CONSTRUCT()   

    HRESULT FinalConstruct()
    {
        return S_OK;
    }

    void FinalRelease()
    {
    }

    static HRESULT s_CreateInstance(IShellItem *psi, REFIID riid, __deref_out void **ppv);   

    // IFilter
    IFACEMETHODIMP Init(ULONG grfFlags, ULONG cAttributes, __deref_in FULLPROPSPEC const *aAttributes, __out ULONG *pFlags);
    IFACEMETHODIMP GetChunk(__deref_out STAT_CHUNK *pStat);
    IFACEMETHODIMP GetText(__inout ULONG *pcwcBuffer, __out_ecount(*pcwcBuffer) WCHAR *awcBuffer);    
    IFACEMETHODIMP GetValue(__deref_out PROPVARIANT **ppPropValue);
    IFACEMETHODIMP BindRegion(FILTERREGION origPos, REFIID riid, __deref_out void **ppunk);    

private:            
    HRESULT _Initialize(IShellItem *psi);

    CComPtr<IShellItem> _spsi;    
    CComPtr<IPropertyStore> _spps;        
    CComPtr<IEnumShellItems> _spenumsi;
    CComPropVariant _spropvarValue;

    enum FILTERSTATE
    {                        
        FS_CHILDREN,
        FS_END,
        FS_PROPERTIES = 0xFFFFFFFF
    } _fs;
    
    ULONG _ulChunkId;
    LCID _lcid;        
    DWORD _cProps;      
};
