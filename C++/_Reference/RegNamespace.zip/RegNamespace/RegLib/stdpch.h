//------------------------------------------------------------------------------
// stdpch.h
//------------------------------------------------------------------------------
// File provided for Microsoft Shared Source.
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF 
// ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO 
// THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A 
// PARTICULAR PURPOSE.
//------------------------------------------------------------------------------
//
// Shared precompiled header file for RegLib/RegNamespace/RegPH
//
//------------------------------------------------------------------------------

#pragma once

#define STRICT

// targeting Windows Vista and above

#define WINVER          _WIN32_WINNT_LONGHORN
#define _WIN32_WINNT    _WIN32_WINNT_LONGHORN
#define _WIN32_WINDOWS  _WIN32_WINNT_LONGHORN

// IE 6.0 and above
#define _WIN32_IE       _WIN32_IE_IE70

#define _ATL_APARTMENT_THREADED
#define _ATL_NO_AUTOMATIC_NAMESPACE

// some CString constructors will be explicit
#define _ATL_CSTRING_EXPLICIT_CONSTRUCTORS

// type safe shell IDList
#define STRICT_TYPED_ITEMIDS

#include <atlbase.h>
#include <atlcom.h>
#include <atlcoll.h>
#include <shlobj.h>
#include <shobjidl.h>
#include <strsafe.h>
#include "ComObjectWithRef.h"

#define INITGUID

using namespace ATL;

#pragma hdrstop

#pragma comment(lib, "reglib.lib")
