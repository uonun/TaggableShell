

/* this ALWAYS GENERATED file contains the definitions for the interfaces */


 /* File created by MIDL compiler version 7.00.0555 */
/* at Mon Apr 06 16:19:30 2009
 */
/* Compiler settings for .\RegNamespace.idl:
    Oicf, W1, Zp8, env=Win32 (32b run), target_arch=X86 7.00.0555 
    protocol : dce , ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
/* @@MIDL_FILE_HEADING(  ) */

#pragma warning( disable: 4049 )  /* more than 64k source lines */


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __RegNamespace_h__
#define __RegNamespace_h__

#if defined(_MSC_VER) && (_MSC_VER >= 1020)
#pragma once
#endif

/* Forward Declarations */ 

#ifndef __IRegValueEditor_FWD_DEFINED__
#define __IRegValueEditor_FWD_DEFINED__
typedef interface IRegValueEditor IRegValueEditor;
#endif 	/* __IRegValueEditor_FWD_DEFINED__ */


#ifndef __IRegPropertyHandler_FWD_DEFINED__
#define __IRegPropertyHandler_FWD_DEFINED__
typedef interface IRegPropertyHandler IRegPropertyHandler;
#endif 	/* __IRegPropertyHandler_FWD_DEFINED__ */


#ifndef __RegFolder_FWD_DEFINED__
#define __RegFolder_FWD_DEFINED__

#ifdef __cplusplus
typedef class RegFolder RegFolder;
#else
typedef struct RegFolder RegFolder;
#endif /* __cplusplus */

#endif 	/* __RegFolder_FWD_DEFINED__ */


#ifndef __RegNamespaceProxy_FWD_DEFINED__
#define __RegNamespaceProxy_FWD_DEFINED__

#ifdef __cplusplus
typedef class RegNamespaceProxy RegNamespaceProxy;
#else
typedef struct RegNamespaceProxy RegNamespaceProxy;
#endif /* __cplusplus */

#endif 	/* __RegNamespaceProxy_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"
#include "shobjidl.h"

#ifdef __cplusplus
extern "C"{
#endif 


/* interface __MIDL_itf_RegNamespace_0000_0000 */
/* [local] */ 

DEFINE_PROPERTYKEY(PKEY_RegistryType, 0xcac4e8d3, 0xdfe0, 0x49cf, 0xb5, 0x60, 0xa3, 0xd4, 0xb4, 0x5d, 0xe7, 0xf5, 2);
DEFINE_PROPERTYKEY(PKEY_RegistryTypeDisplay, 0xcac4e8d3, 0xdfe0, 0x49cf, 0xb5, 0x60, 0xa3, 0xd4, 0xb4, 0x5d, 0xe7, 0xf5, 5);
DEFINE_PROPERTYKEY(PKEY_RegistryData, 0xcac4e8d3, 0xdfe0, 0x49cf, 0xb5, 0x60, 0xa3, 0xd4, 0xb4, 0x5d, 0xe7, 0xf5, 3);
DEFINE_PROPERTYKEY(PKEY_RegistryDataDisplay, 0xcac4e8d3, 0xdfe0, 0x49cf, 0xb5, 0x60, 0xa3, 0xd4, 0xb4, 0x5d, 0xe7, 0xf5, 4);


extern RPC_IF_HANDLE __MIDL_itf_RegNamespace_0000_0000_v0_0_c_ifspec;
extern RPC_IF_HANDLE __MIDL_itf_RegNamespace_0000_0000_v0_0_s_ifspec;

#ifndef __IRegValueEditor_INTERFACE_DEFINED__
#define __IRegValueEditor_INTERFACE_DEFINED__

/* interface IRegValueEditor */
/* [local][unique][helpstring][uuid][object] */ 


EXTERN_C const IID IID_IRegValueEditor;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("FD5FBAE8-BECF-4F82-8859-813A43BB9D1A")
    IRegValueEditor : public IUnknown
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE EditModal( 
            /* [in] */ HWND hwndParent) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IRegValueEditorVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IRegValueEditor * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            __RPC__deref_out  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IRegValueEditor * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IRegValueEditor * This);
        
        HRESULT ( STDMETHODCALLTYPE *EditModal )( 
            IRegValueEditor * This,
            /* [in] */ HWND hwndParent);
        
        END_INTERFACE
    } IRegValueEditorVtbl;

    interface IRegValueEditor
    {
        CONST_VTBL struct IRegValueEditorVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IRegValueEditor_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IRegValueEditor_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IRegValueEditor_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IRegValueEditor_EditModal(This,hwndParent)	\
    ( (This)->lpVtbl -> EditModal(This,hwndParent) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IRegValueEditor_INTERFACE_DEFINED__ */


/* interface __MIDL_itf_RegNamespace_0000_0001 */
/* [local] */ 

STDAPI CreateValueEditor(__in IShellItem2 *psi, REFIID riid, __deref_out void **ppv);


extern RPC_IF_HANDLE __MIDL_itf_RegNamespace_0000_0001_v0_0_c_ifspec;
extern RPC_IF_HANDLE __MIDL_itf_RegNamespace_0000_0001_v0_0_s_ifspec;

#ifndef __IRegPropertyHandler_INTERFACE_DEFINED__
#define __IRegPropertyHandler_INTERFACE_DEFINED__

/* interface IRegPropertyHandler */
/* [local][unique][helpstring][uuid][object] */ 


EXTERN_C const IID IID_IRegPropertyHandler;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("28BA7B06-D324-4fb0-A26C-409F7BC265D0")
    IRegPropertyHandler : public IUnknown
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE GetProperty( 
            /* [in] */ PCUITEMID_CHILD pidl,
            /* [in] */ REFPROPERTYKEY key,
            /* [out] */ PROPVARIANT *ppropvar) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetProperty( 
            /* [in] */ PCUITEMID_CHILD pidl,
            /* [in] */ REFPROPERTYKEY key,
            /* [in] */ REFPROPVARIANT propvar) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IRegPropertyHandlerVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IRegPropertyHandler * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            __RPC__deref_out  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IRegPropertyHandler * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IRegPropertyHandler * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetProperty )( 
            IRegPropertyHandler * This,
            /* [in] */ PCUITEMID_CHILD pidl,
            /* [in] */ REFPROPERTYKEY key,
            /* [out] */ PROPVARIANT *ppropvar);
        
        HRESULT ( STDMETHODCALLTYPE *SetProperty )( 
            IRegPropertyHandler * This,
            /* [in] */ PCUITEMID_CHILD pidl,
            /* [in] */ REFPROPERTYKEY key,
            /* [in] */ REFPROPVARIANT propvar);
        
        END_INTERFACE
    } IRegPropertyHandlerVtbl;

    interface IRegPropertyHandler
    {
        CONST_VTBL struct IRegPropertyHandlerVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IRegPropertyHandler_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IRegPropertyHandler_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IRegPropertyHandler_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IRegPropertyHandler_GetProperty(This,pidl,key,ppropvar)	\
    ( (This)->lpVtbl -> GetProperty(This,pidl,key,ppropvar) ) 

#define IRegPropertyHandler_SetProperty(This,pidl,key,propvar)	\
    ( (This)->lpVtbl -> SetProperty(This,pidl,key,propvar) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IRegPropertyHandler_INTERFACE_DEFINED__ */


/* interface __MIDL_itf_RegNamespace_0000_0002 */
/* [local] */ 

STDAPI CreateRegistryPropertyStoreFactory(__in IShellFolder *psf, PCUITEMID_CHILD pidlChild, REFIID riid, __deref_out void **ppv);


extern RPC_IF_HANDLE __MIDL_itf_RegNamespace_0000_0002_v0_0_c_ifspec;
extern RPC_IF_HANDLE __MIDL_itf_RegNamespace_0000_0002_v0_0_s_ifspec;


#ifndef __RegNamespaceLib_LIBRARY_DEFINED__
#define __RegNamespaceLib_LIBRARY_DEFINED__

/* library RegNamespaceLib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_RegNamespaceLib;

EXTERN_C const CLSID CLSID_RegFolder;

#ifdef __cplusplus

class DECLSPEC_UUID("E48ABDCD-0DE7-4C5A-91EB-13D6E81506F0")
RegFolder;
#endif

EXTERN_C const CLSID CLSID_RegNamespaceProxy;

#ifdef __cplusplus

class DECLSPEC_UUID("8D4C9693-7368-43EE-8591-7509F4A5C57D")
RegNamespaceProxy;
#endif
#endif /* __RegNamespaceLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif


