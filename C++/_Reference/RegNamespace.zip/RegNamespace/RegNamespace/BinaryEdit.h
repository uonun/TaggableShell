//------------------------------------------------------------------------------
// BinaryEdit.h
//------------------------------------------------------------------------------
// File provided for Microsoft Shared Source.
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF 
// ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO 
// THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A 
// PARTICULAR PURPOSE.
//------------------------------------------------------------------------------
//
// Binary edit control
//
//------------------------------------------------------------------------------

#pragma once

#define BES_TOOLBAR 0x00000001

STDAPI CreateBinaryEdit(HWND hwndParent, DWORD dwStyle, RECT &rc, UINT uiId, __out HWND *phwnd);

#define BEM_SETDATA         (WM_USER+1)     // wParam = UINT cb, lParam = const BYTE *pb
#define BEM_GETDATASIZE     (WM_USER+2)
#define BEM_GETDATA         (WM_USER+3)     // lParam = UINT cb, lParam = BYTE *pb

enum HEXCELLTYPE
{
    HCT_INVALID = 0,
    HCT_BYTE,
    HCT_WORD,
    HCT_DWORD,
    HCT_QWORD,
    HCT_MAX,
};
#define BEM_SETHEXCELLTYPE  (WM_USER+4)     // lParam = HEXCELLTYPE
#define BEM_GETHEXCELLTYPE  (WM_USER+5)

enum HEXCELLDIVIDERTYPE
{
    HCDT_INVALID = 0,
    HCDT_NONE,
    HCDT_BYTE,
    HCDT_WORD,
    HCDT_DWORD,
    HCDT_QWORD,
    HCDT_AUTO,
    HCDT_MAX
};
#define BEM_SETHEXCELLDIVIDERTYPE   (WM_USER+6)     // lParam = HEXCELLDIVIDERTYPE
#define BEM_GETHEXCELLDIVIDERTYPE   (WM_USER+7)

#define BEM_SETALTERNATEROWCOLOR    (WM_USER+8)     // lParam = TRUE/FALSE
#define BEM_GETALTERNATEROWCOLOR    (WM_USER+9)
