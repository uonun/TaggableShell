//------------------------------------------------------------------------------
// resids.h
//------------------------------------------------------------------------------
// File provided for Microsoft Shared Source.
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF 
// ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO 
// THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A 
// PARTICULAR PURPOSE.
//------------------------------------------------------------------------------
//
// Resource IDs
//
//------------------------------------------------------------------------------

/////////////////////////////////////////////////////////////////////////////
//
// Icons
//

#define IDI_NAMESPACEROOT       100
#define IDI_REGFOLDER           101
#define IDI_UNUSED              102
#define IDI_REGSTRINGVALUE      103
#define IDI_REGBINARYVALUE      104

/////////////////////////////////////////////////////////////////////////////
//
// Registry IDs
//

#define IDR_REGFOLDER       101

/////////////////////////////////////////////////////////////////////////////
//
// String IDs
//

#define IDS_PROJNAME                    0x0100
#define IDS_DEFAULTVALUE                0x0101
#define IDS_EMPTYDEFAULT                0x0102

#define IDS_REGSZ_TITLE                 0x0200
#define IDS_REGMULTISZ_TITLE            0x0201
#define IDS_REGDWORD_TITLE              0x0202
#define IDS_REGQWORD_TITLE              0x0203
#define IDS_REGBINARY_TITLE             0x0204

#define IDS_TD_TITLE                        0x0300
#define IDS_TD_EMPTIESREMOVEDINSTRUCTION    0x0301
#define IDS_TD_EMPTIESREMOVEDCONTENT        0x0302

#define IDS_NUMERICEDIT_INVALIDCHARTITLE    0x0400
#define IDS_NUMERICEDIT_DECIMALMESSAGE      0x0401
#define IDS_NUMERICEDIT_HEXMESSAGE          0x0402
#define IDS_NUMERICEDIT_INVALIDPASTETITLE   0x0403
#define IDS_NUMERICEDIT_PASTEARG            0x0404
#define IDS_NUMERICEDIT_PASTEOVERFLOW       0x0405
#define IDS_NUMERICEDIT_PASTEFAILED         0x0406

// The following IDs should be static.  There are hardcoded references to them
// in the registry or the property schema

#define IDS_ROOTFOLDERDISPLAYNAME       0x1000
#define IDS_TYPEPROPNAME                0x1001
#define IDS_TYPENONE                    0x1002
#define IDS_TYPESZ                      0x1003
#define IDS_TYPEEXPANDSZ                0x1004
#define IDS_TYPEBINARY                  0x1005
#define IDS_TYPEDWORD                   0x1006
#define IDS_TYPEDWORDBIGENDIAN          0x1007
#define IDS_TYPELINK                    0x1008
#define IDS_TYPEMULTISZ                 0x1009
#define IDS_TYPEQWORD                   0x100a
#define IDS_TYPEKEY                     0x100b
#define IDS_DATAPROPNAME                0x100c

/////////////////////////////////////////////////////////////////////////////
//
// HTML IDs
//

#define IDR_REGPROPSCHEMA   100

/////////////////////////////////////////////////////////////////////////////
//
// Menu IDs
//

#define IDM_VALUE_MERGE     0x0100
#define IDM_EDITVALUE       0x0001

/////////////////////////////////////////////////////////////////////////////
//
// Dialog IDs
//

#define IDD_REGSZ_EDITOR        100
#define IDD_REGMULTISZ_EDITOR   101
#define IDD_REGNUMBER_EDITOR    102
#define IDD_REGBINARY_EDITOR    103

#define IDC_VALUEICON           100
#define IDC_VALUENAME           101
#define IDC_VALUEDATA           102
#define IDC_PLACEHOLDER         103
#define IDC_BASE_HEX            104
#define IDC_BASE_DECIMAL        105
