//------------------------------------------------------------------------------
// BinaryEditIds.h
//------------------------------------------------------------------------------
// File provided for Microsoft Shared Source.
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF 
// ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO 
// THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A 
// PARTICULAR PURPOSE.
//------------------------------------------------------------------------------
//
// Resources IDs for the binary edit control
//
//------------------------------------------------------------------------------

#pragma once

/////////////////////////////////////////////////////////////////////////////
//
// Icons
//

#define IDI_HEXCOLUMNSIZE       105
#define IDI_ALTERNATEROWCOLOR   106
#define IDI_COLUMNDIVIDERS      107

/////////////////////////////////////////////////////////////////////////////
//
// Menu IDs
//

#define IDM_BINARYEDIT_HEXCELLTYPE          0x0101
#define IDM_BINARYEDIT_HEXCELLDIVIDERTYPE   0x0102

// Cell type IDs.  These must stay in sync with the HEXCELLTYPE enum
#define IDM_HEXCELLTYPE_BYTE        0x0001
#define IDM_HEXCELLTYPE_WORD        0x0002
#define IDM_HEXCELLTYPE_DWORD       0x0003
#define IDM_HEXCELLTYPE_QWORD       0x0004

// Cell divider type IDs.  These must stay in sync with the HEXCELLDIVIDERTYPE enum
#define IDM_HEXCELLDIVIDERTYPE_NONE     0x0001
#define IDM_HEXCELLDIVIDERTYPE_BYTE     0x0002
#define IDM_HEXCELLDIVIDERTYPE_WORD     0x0003
#define IDM_HEXCELLDIVIDERTYPE_DWORD    0x0004
#define IDM_HEXCELLDIVIDERTYPE_QWORD    0x0005
#define IDM_HEXCELLDIVIDERTYPE_AUTO     0x0006

/////////////////////////////////////////////////////////////////////////////
//
// String IDs
//

#define IDS_TOOLBARTIPS     0x4000
