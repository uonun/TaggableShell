//------------------------------------------------------------------------------
// pch.h
//------------------------------------------------------------------------------
// File provided for Microsoft Shared Source.
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF 
// ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO 
// THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A 
// PARTICULAR PURPOSE.
//------------------------------------------------------------------------------
//
// Precompiled header
//
//------------------------------------------------------------------------------

#include <stdpch.h>

#include <IDListUtils.h>
#include <PropVariant.h>
#include <MemUtils.h>
#include <StackString.h>
#include "resids.h"
#include "Utils.h"
