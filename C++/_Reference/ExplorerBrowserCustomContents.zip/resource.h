// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
// ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
// THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
//
// Copyright  Microsoft Corporation. All rights reserved

// Microsoft Visual C++ generated include file.

#define IDD_DIALOG1                     100
#define IDC_BROWSER                     101
#define IDC_STATIC                      102
#define IDC_CANCEL                      103
#define IDC_REFRESH                     104
#define IDC_EXPLORE                     105
#define IDC_ENUMNAME                    106
#define IDC_ENUMPATH                    107
#define IDC_STATUS                      108
#define IDC_FOLDERNAME                  109
#define IDC_FOLDERPATH                  110
#define IDC_LBLFOLDER                   111
#define IDC_LBLPATH                     112
