// CopyTcharToPidl.cpp: implementation of the CCopyTcharToPidl class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "CopyTcharToPidl.h"

CPidlMgr CCopyTcharToPidl::m_PidlMgr;
