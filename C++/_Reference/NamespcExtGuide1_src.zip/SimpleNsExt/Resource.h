//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SimpleNsExt.rc
//
#define IDS_PROJNAME                    100
#define IDR_SHELLFOLDERIMPL             101
#define IDI_ICON1                       201
#define IDB_IMGLIST_SMALL               202
#define IDB_IMGLIST_LARGE               203
#define IDR_NONFOCUS                    205
#define IDR_FOCUS                       206
#define IDR_LIST_CTXMENU                207
#define IDD_ABOUTDLG                    208
#define IDC_ABOUT_SIMPLENS              2000
#define IDC_SYS_PROPERTIES              3000
#define IDC_EXPLORE_DRIVE               3001

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        209
#define _APS_NEXT_COMMAND_VALUE         3002
#define _APS_NEXT_CONTROL_VALUE         201
#define _APS_NEXT_SYMED_VALUE           105
#endif
#endif
